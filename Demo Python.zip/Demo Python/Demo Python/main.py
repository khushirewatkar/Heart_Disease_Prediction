import streamlit as st
import numpy as np
from PIL import Image
from tensorflow.keras.models import load_model
import os

# Loading of pre-trained model
model_path = 'saved models.h5'
if os.path.exists(model_path):
    try:
        model = load_model(model_path)
    except Exception as e:
        st.error(f"Error loading the model: {str(e)}")
else:
    st.error("Model file not found. Please provide the correct path to your trained model.")

# Treatments and precautions
classes = ['Arrhythmia', 'Left Bundle Branch', 'Normal', 'PVC', 'Right Bundle Branch', 'Ventricular Fibrillation']
cure_precautions = {
    'Arrhythmia': {
        'Treatment': """
            - **Medication**: Antiarrhythmic drugs like beta-blockers, calcium channel blockers, or amiodarone can help regulate the heart rhythm.
            - **Cardioversion**: Electrical shock therapy can reset the heart rhythm in severe cases.
            - **Pacemaker/ICD**: In life-threatening cases, a pacemaker or ICD may be implanted.
            - **Ablation Therapy**: Catheter ablation targets and destroys abnormal heart tissue causing arrhythmia.
        """,
        'Precautions': """
            - **Avoid Caffeine, Alcohol, and Stimulants**: These can trigger arrhythmia in some people.
            - **Manage Stress**: Use stress management techniques like meditation or yoga to prevent arrhythmias.
            - **Regular Check-ups**: Routine ECGs and monitoring for those at risk.
        """
    },
    'Ventricular Fibrillation': {
        'Treatment': """
            - **Immediate Defibrillation**: VF is a medical emergency; an AED can be life-saving.
            - **ICD Implantation**: For those at high risk of VF, an ICD may be implanted to detect and correct VF.
            - **Medication**: Drugs like amiodarone or lidocaine may be used in emergencies.
        """,
        'Precautions': """
            - **Manage Heart Disease Risk Factors**: Controlling blood pressure, cholesterol, and diabetes can reduce VF risk.
            - **Avoid Stimulants**: Drugs that can increase heart rate may worsen VF risk.
            - **Regular Cardiac Monitoring**: At-risk individuals should monitor their heart with ECG or wearable devices.
        """
    },
    'Left Bundle Branch': {
        'Treatment': """
            - **Address Underlying Conditions**: Treating hypertension, coronary artery disease, or heart failure can improve LBBB.
            - **Pacemaker**: In severe cases, a pacemaker may be implanted to improve heart rhythm.
        """,
        'Precautions': """
            - **Regular Heart Monitoring**: Routine ECGs can help detect changes in LBBB.
            - **Healthy Lifestyle**: Diet, exercise, and avoiding smoking reduce stress on the heart.
        """
    },
    'PVC': {
        'Treatment': """
            - **Medication**: Beta-blockers or calcium channel blockers may reduce the frequency of PVCs.
            - **Lifestyle Changes**: Reducing caffeine, alcohol, and stress can help prevent PVCs.
            - **Ablation Therapy**: If PVCs are frequent and symptomatic, ablation may be an option.
        """,
        'Precautions': """
            - **Reduce Stimulants**: Avoid caffeine, nicotine, and alcohol, which can trigger PVCs.
            - **Regular Check-ups**: Track PVC frequency if they are common and consult a cardiologist if they increase.
            - **Stress Management**: Reducing stress can be beneficial in preventing PVCs.
        """
    },
    'Right Bundle Branch': {
        'Treatment': """
            - **Usually No Treatment Necessary**: RBBB is often benign and does not need treatment if no other cardiac issues exist.
            - **Pacemaker**: May be recommended if RBBB is associated with heart failure or if both bundle branches are blocked.
        """,
        'Precautions': """
            - **Regular Monitoring**: ECGs can detect changes over time.
            - **Address Heart Conditions**: Managing underlying issues like heart disease is essential.
            - **Healthy Lifestyle**: A balanced diet, exercise, and avoiding smoking support heart health.
        """
    },
    'Normal': {
        'Treatment': "- No treatment necessary.",
        'Precautions': """
            - **Healthy Lifestyle**: Maintain a healthy lifestyle with regular exercise.
            - **Balanced Diet**: Eat a balanced diet to support overall health.
        """
    }
}

# Function to preprocess the image
def preprocess_image(image):
    if image.mode != "RGB":
        image = image.convert("RGB")
    image = image.resize((64, 64))
    img_array = np.array(image)
    img_array = img_array / 255.0
    img_array = np.expand_dims(img_array, axis=0)
    return img_array

# Function to make predictions with a confidence distribution 
def make_prediction(image, threshold=0.8):
    processed_img = preprocess_image(image)
    
    if processed_img.shape != (1, 64, 64, 3):
        return None, 0, "The image does not appear to be in the expected format for an ECG. Please upload a valid ECG image."
    
    prediction = model.predict(processed_img)
    confidence = np.max(prediction)
    
    confidence_distribution = prediction / np.sum(prediction)
    max_confidence = np.max(confidence_distribution)
    
    if max_confidence < threshold:
        return None, max_confidence, "The model is not confident that this is an ECG image. Please upload a clear ECG image."
    
    predicted_class = classes[np.argmax(prediction)]
    return predicted_class, max_confidence, ""

def main():
    st.markdown(
        """
        <style>
        .heartbeat {
            animation: heartbeat 1s infinite;
            color: red;
            display: inline-block;
        }
        @keyframes heartbeat {
            0%, 100% {
                transform: scale(1);
            }
            50% {
                transform: scale(1.2); /* Slightly larger at midpoint */
            }
        }
        .prediction-box {
            border: 2px solid #007BFF;
            padding: 20px;
            border-radius: 8px;
            margin-top: 20px;
            animation: fadeIn 1s ease-in;
        }
        .confidence {
            color: #4CAF50;
            font-weight: bold;
        }
        .download-button {
            display: inline-block;
            padding: 10px 20px;
            font-size: 16px;
            color: #007BFF;  /* Darker color for visibility */
            background-color: #E0F7FA;  /* Light background */
            border: 2px solid #007BFF;  /* Border for contrast */
            border-radius: 5px;
            text-decoration: none;
            font-weight: bold;
        }
        .download-button:hover {
            background-color: #B2EBF2;
        }
        </style>
        """,
        unsafe_allow_html=True
    )

    st.markdown('<h1><span class="heartbeat">❤️</span> Heart Health Analysis</h1>', unsafe_allow_html=True)
    st.sidebar.title('Upload ECG Image')

    # download button for sample ECG images
    st.sidebar.markdown(
        """
        <p>If you don't have an ECG image, you can download samples from our dataset below:</p>
        <a href="https://drive.google.com/drive/folders/1wOn5Yt87_Y2JTY0yhfYB-inROy35cSpy?usp=sharing" 
        class="download-button" target="_blank">Download Sample ECG Images</a>
        """,
        unsafe_allow_html=True
    )

    uploaded_file = st.sidebar.file_uploader("Choose an ECG image...", type=["png"])

    if uploaded_file is not None:
        image = Image.open(uploaded_file)
        st.image(image, caption='Uploaded ECG Image', use_column_width=True)

        if st.button('Predict'):
            prediction, confidence, error_message = make_prediction(image)
            if error_message:
                st.warning(error_message)
            elif prediction is None:
                st.warning("The model could not identify this as an ECG image with sufficient confidence.")
            else:
                st.markdown(
                    f"""
                    <div class="prediction-box">
                        <h3>Prediction: <span style='color: #007BFF;'>{prediction}</span></h3>
                        <p>Confidence: <span class="confidence">{confidence:.2f}</span></p>
                    </div>
                    """, 
                    unsafe_allow_html=True
                )

                # Display Treatment and Precautions
                cure_info = cure_precautions.get(prediction, None)
                if cure_info:
                    st.subheader("Treatment and Precautions")
                    st.markdown(f"**Treatment:**\n{cure_info['Treatment']}", unsafe_allow_html=True)
                    st.markdown(f"**Precautions:**\n{cure_info['Precautions']}", unsafe_allow_html=True)
                else:
                    st.info("No specific treatment or precaution details available for this prediction.")

if __name__ == "__main__":
    main()
